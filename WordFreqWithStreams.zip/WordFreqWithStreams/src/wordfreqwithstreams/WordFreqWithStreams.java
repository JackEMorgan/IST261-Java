package wordfreqwithstreams;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.Map;
import java.util.Scanner;
import static java.util.stream.Collectors.counting;
import static java.util.stream.Collectors.groupingBy;
import java.util.stream.Stream;

public class WordFreqWithStreams {

    public static void main(String[] args) throws FileNotFoundException, IOException {
        
        String fileName = "GettysburgAddress.txt";
        BufferedReader br = new BufferedReader(new FileReader(fileName));
        String line;
        String file = "";
        while ((line = br.readLine()) != null) {
            file += line;
        }
        
        // don't change any code below this line
        Map<String, Long> freq;
        try (Stream<String> words = new Scanner(file).tokens()) {
            freq = words
                    .collect(groupingBy(String::toLowerCase, counting()));
        }
        System.out.println(freq);
    }

}
