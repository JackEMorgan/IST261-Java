package duplicatechecker;

import java.util.Arrays;
import java.util.List;

public class DuplicateChecker {

    public static void main(String[] args) {
        System.out.println(hasDuplicateIntegers());
    }

    static boolean hasDuplicateIntegers() {
        List<Integer> listOfIntegers = Arrays.asList(1, 2, 3, 4, 2, 6);
        int duplicateCount = 0;
        for (int i : listOfIntegers) {
            for (int j : listOfIntegers) {
                if (i == j) {
                    duplicateCount += 1;
                    if (duplicateCount >= listOfIntegers.size() + 1) {
                        return true;
                    }
                }
            }
        }
    return false;    
    }
}
