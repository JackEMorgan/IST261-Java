package csvapp;

public class GeographicRegion {
    private final String name;
    private final String area;
    
    public GeographicRegion(String name, String area) {
        this.name = name;
        this.area = area;
    }
    
    @Override
    public String toString() {
        return "Name: " + name + "; Area: " + area + " sq. km";
    } 
}