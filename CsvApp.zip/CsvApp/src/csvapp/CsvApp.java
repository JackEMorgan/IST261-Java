package csvapp;

import com.opencsv.CSVReaderHeaderAware;
import com.opencsv.exceptions.CsvValidationException;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class CsvApp {

    public static void main(String[] args) throws FileNotFoundException, IOException, CsvValidationException {
        List<GeographicRegion> regionList = populateList("RegionsAndAreas.csv");
        Chooser<GeographicRegion> countryChooser = new Chooser<>(regionList);
        for (int i = 0; i < 10; i++) {
            System.out.println(countryChooser.choose());
        }
    }

    private static List<GeographicRegion> populateList(String fileName) throws FileNotFoundException, IOException, CsvValidationException  {
        ArrayList<GeographicRegion> regionList = new ArrayList<>();
        FileReader fr = new FileReader(fileName);
        BufferedReader br = new BufferedReader(fr);
        Map<String, String> values = new CSVReaderHeaderAware(br).readMap();
        String line;
        while ((line = br.readLine()) != null) {
            String[] parts = line.split(",");
            values.put(parts[0].trim(), parts[parts.length-1]);
            GeographicRegion country = new GeographicRegion(parts[0].trim(), parts[parts.length - 1].trim());
            regionList.add(country);
        }
        return regionList;
    }
}