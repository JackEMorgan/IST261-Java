package uncheckedWarning;

import java.util.ArrayList;
import java.util.List;

/**
 * INSTRUCTIONS:
 * 
 * Complete this program so that it doesn't show a warning about "unchecked"
 * operations or conversions when the program is cleaned and built.
 * 
 * GRADING: 
 * 
 * 100 points if program does not show a warning about "unchecked"
 * operations or conversions when the program is cleaned and built;
 * 
 * 0 points otherwise.
 * 
 * RESTRICTIONS: The only allowed resources are NetBeans and your brain.
 * 
 */
public class UncheckedWarning {
    public static void main(String[] args) {
        ArrayList<Integer> listOfIntegers = new ArrayList<>();
        listOfIntegers.add(0);
        System.out.println("The listOfInteger is " + listOfIntegers);
    }  
}
