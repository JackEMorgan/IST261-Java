package regexhomework;


/**
 * INSTRUCTIONS:
 *
 * Write the same regular expression inside the quotation marks in the two
 * matches methods below so that 
 * 
 * the regular expression you write
 *
 * 1. matches just any String that starts with exactly two digits from 
 * 0 through 9, which are followed immediately by one or more 
 * whitespace characters, which are followed immediately by a single digit 
 * from 0 through 9 that ends the String.
 *
 * 2. uses only \s, \d, and +, appropriately arranged and escaped
 *
 * Your program must run without errors and print to the console
 * 
 * true
 * false
 * 
 * based on a single *correct* regular expression that you write inside 
 * each matches method.
 *
 * Be sure to write the *same* regular expression inside both matches methods.
 * 
 * Do not change any other code that is given in this program.
 *
 * GRADING CRITERIA:
 *
 * 100 points if your program does what is asked for in the instructions
 *
 * 50 points if 
 * 
 * 1) your program is correct, but uses expressions that include
 * not just \s, \d, and +, appropriately arranged and escaped; 
 * 
 * OR 
 * 
 * 2) your program was built with a JDK other than JDK 19
 * 
 * 0 points, otherwise
 *
 * RESTRICTIONS: The only allowed resources are NetBeans, your brain, and the Web.
 *
 *
 */
public class RegexHomework {

    public static void main(String[] args) {
        String text =  "22\f\n 4";
        String moreText = "2 \t\r\n 44 ";
        System.out.println(text.matches("\\d\\d\\s+\\d"));
        System.out.println(moreText.matches("\\d\\s\\d\\d"));
    }

}
