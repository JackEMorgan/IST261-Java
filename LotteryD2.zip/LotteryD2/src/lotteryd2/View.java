package lotteryd2;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public final class View extends JFrame {

    private static final int FRAME_WIDTH = 850;
    private static final int FRAME_HEIGHT = 300;

    private static final int AREA_ROWS = 11;
    private static final int AREA_COLUMNS = 50;

    private static final String INPUT_SPECIFIER = "\nEnter six integers "
            + "from 0 through 60 inclusive, "
            + "separated by one or more spaces with no leading or trailing "
            + "whitespace. ";
   
    private JLabel label;
    private JTextField textField;
    private JButton button;
    private final JTextArea resultArea;
    
    private JLabel lableUserNums;
    private JTextField textFieldNumDrawings;
    
    private final Controller cntl;

    public View(Controller controller) {
        cntl = controller;

        resultArea = new JTextArea(AREA_ROWS, AREA_COLUMNS);
        resultArea.setEditable(false);
        resultArea.setText("");

        createTextField();
        createButton();
        createPanel();

        setSize(FRAME_WIDTH, FRAME_HEIGHT);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        getRootPane().setDefaultButton(button);
    }

    private void createTextField() {
        label = new JLabel(INPUT_SPECIFIER);
        final int FIELD_WIDTH = 10;
        textField = new JTextField(FIELD_WIDTH);
        lableUserNums = new JLabel("Enter just one intger from 1 through 10 with no trailing whitespace");
        textFieldNumDrawings = new JTextField(FIELD_WIDTH);
    }

    private void createButton() {
        button = new JButton("Compare Nums");
        button.addActionListener(event -> showLottoResults(textField.getText(), 
                textFieldNumDrawings.getText()));
    }

    private void createPanel() {
        JPanel panel = new JPanel();
        panel.add(label);
        panel.add(textField);
        panel.add(lableUserNums);
        panel.add(textFieldNumDrawings);
        JScrollPane scrollPane = new JScrollPane(resultArea);
        panel.add(scrollPane);
        panel.add(button);
        add(panel);
    }

    private void showLottoResults(String userNums, String numDrawings) {
        resultArea.setText(cntl.doLotteryDrawing(userNums, numDrawings) + "\n");
    }

    public void showErrorMsg(String howToFixInputError) {
        javax.swing.JOptionPane.showMessageDialog(new javax.swing.JFrame(),
                "Invalid Input: " + textField.getText() + "\n"
                + howToFixInputError);
        textField.setText("");
        textFieldNumDrawings.setText("");
        textField.requestFocus();
    }

    public void displaySelf() {
        this.setVisible(true);
    }
}
