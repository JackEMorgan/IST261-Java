package lotteryd2;

import java.util.HashSet;
import java.util.Random;

public class Model {
    
    private final HashSet<Integer> lottoResults;
    
    public Model() {
        lottoResults = new HashSet<>();
    }
    
    public HashSet<Integer> getLottoResults() {
        boolean results = false;
        lottoResults.clear();
        while (results != true) {
            int randInt = 0;
            while (randInt == 0 ) {
                randInt = new Random().nextInt(61);
            }
            if (lottoResults.contains(randInt)) {
                lottoResults.clear();
            }
            lottoResults.add(randInt); 
            if (lottoResults.size() >= 6) {
                results = true;
            }
        }
        return lottoResults;
    }
}