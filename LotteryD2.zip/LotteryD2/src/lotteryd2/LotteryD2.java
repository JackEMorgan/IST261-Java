package lotteryd2;

public class LotteryD2 {

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> {
            Controller cntl = new Controller();
            cntl.getView().displaySelf();
        });
    }
}
