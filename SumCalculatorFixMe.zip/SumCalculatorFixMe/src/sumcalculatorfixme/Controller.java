package sumcalculatorfixme;

public class Controller {

    private final Model model;
    private final View view;

    public Controller() {
        model = new Model();
        view = new View(this);
    }

    public String computeSum(String nums) {
        nums = nums.trim();
        String[] arrayNums = nums.split("\\s+");
        if (arrayNums.length == 6) {
            for (String num : arrayNums) {
                if (!num.matches("\\d{1,2}" )) {
                    this.view.showErrorMsg("Invalid input");
                    return "";
                }
            }
            return "" + model.computeSum(arrayNums);
        }   
        this.view.showErrorMsg(arrayNums.length + " inputs found, 6 inputs expected");
        return "";
    }


    public View getView() {
        return view;
    }

}
