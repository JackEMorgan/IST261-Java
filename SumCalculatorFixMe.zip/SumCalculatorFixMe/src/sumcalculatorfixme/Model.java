package sumcalculatorfixme;

public class Model {

    private int sum;

    public Model() {
        sum = 0;
    }

    public String computeSum(String[] numbers) {
        sum = 0;
        for (String number: numbers) {
            sum += Integer.parseInt(number);
        }
        return "" + sum;
    }
}
