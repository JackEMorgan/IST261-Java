package listgettimer;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Random;

public class ListGetTimer {

    public static void main(String[] args) {
        ArrayList<Integer> intArray = new ArrayList<>();
        Random randInt = new Random();
        for (int i = 0; i < 1000; i++) {
            intArray.add(randInt.nextInt(10001));
        }
        LinkedList<Integer> intLL = new LinkedList<>();
        for (int i = 0; i < 1000; i++) {
            intLL.add(randInt.nextInt(10001));
        }
        
        long arrayTimeStart = System.nanoTime();
        for (int i = 0; i < 1000000; i++) {
            int index = randInt.nextInt(intArray.size() - 1);
            intArray.get(index);
        }
        long arrayTimeEnd = System.nanoTime();
        long arrayTime = (arrayTimeEnd - arrayTimeStart) / 1000000;
        System.out.println("ArrayList Average Time: " + arrayTime);
        
        long llTimeStart = System.nanoTime();
        for (int i = 0; i < 1000000; i++) {
            int index = randInt.nextInt(intLL.size() - 1);
            intLL.get(index);
        }
        long llTimeEnd = System.nanoTime();
        long llTime = (llTimeEnd - llTimeStart) / 1000000;
        System.out.println("Linked List Average Time: " + llTime);
    }
}