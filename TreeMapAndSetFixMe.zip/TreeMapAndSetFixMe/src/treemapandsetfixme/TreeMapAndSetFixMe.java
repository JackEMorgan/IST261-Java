package treemapandsetfixme;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class TreeMapAndSetFixMe {

    public static void main(String[] args) throws FileNotFoundException, IOException {
        String fileName = "GettysburgAddress.txt";
        BufferedReader br = new BufferedReader(new FileReader(fileName));
        Map<String, Integer> stringCountMap = new HashMap<>();
        String line;
        while ((line = br.readLine()) != null) {
            String processedLine = line.replaceAll("[^a-zA-Z0-9]"," ").toLowerCase().replaceAll("( )+", " ");
            String[] words = processedLine.split(" ");
            for (String word : words) {
                if (stringCountMap.containsKey(word) == false) {
                    stringCountMap.put(word, 1);
                } 
                else {
                    int value = stringCountMap.get(word);
                    value++;
                    stringCountMap.put(word, value);
                }
            }
        }    
        System.out.println(stringCountMap);
        TreeMap<Integer, Set<String>> wordCountMap = new TreeMap<>();
        for (String word : stringCountMap.keySet()) {
            int count = stringCountMap.get(word);
            if (wordCountMap.containsKey(count) == false) {
                Set<String> wordCount = new TreeSet<>();
                wordCount.add(word);
                wordCountMap.put(count, wordCount);
            }
            else {
                Set<String> wordCount = wordCountMap.get(count);
                wordCount.add(word);
                wordCountMap.put(count, wordCount);
            }
        }
        for (Map.Entry<Integer, Set<String>> pair : wordCountMap.entrySet()) {
            System.out.println(pair.getKey() + ": " + pair.getValue()); }
    }
}