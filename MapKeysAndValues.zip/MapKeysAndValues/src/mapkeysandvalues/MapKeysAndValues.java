package mapkeysandvalues;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MapKeysAndValues {

    public static void main(String[] args) {
        Map<String, Double> studentGpaMap = new HashMap<>();
        
        try {
            Scanner s = new Scanner(new File("StudentGpaMap.txt"));
            while (s.hasNextLine()) {
                String text = s.next();
                Double value = s.nextDouble();
                studentGpaMap.put(text, value);
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(MapKeysAndValues.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        printKeyValuePairs(studentGpaMap);
    }

    private static void printKeyValuePairs(Map<String, Double> map) {
        System.out.println("\nkey-value pairs using for loop and Map.Entry");
        for (Map.Entry<String, Double> pair : map.entrySet()) {
            System.out.println("Key = " + pair.getKey() + 
                    ", Value = " + pair.getValue()); }
        
        System.out.println("\nkey-value pairs using lambda expression and .foreach()");
        map.forEach((k,v)->System.out.println("Key = " + k + ", Value = " + v));
        
        System.out.println("\nkey-value pairs using Iterator of appropriate type and while loop");
        Iterator<Map.Entry<String, Double>> itr = map.entrySet().iterator();
        while (itr.hasNext()) {
            Map.Entry<String, Double> pair = itr.next();
            System.out.println("Key = " + pair.getKey() + ", Value = " + pair.getValue()); }
        
        System.out.println("\nkey-value pairs using streams");
        map.entrySet().stream().forEach(e -> System.out.println("Key = " + e.getKey() + ", Value = " + e.getValue())); }
}
