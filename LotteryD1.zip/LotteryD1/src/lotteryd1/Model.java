package lotteryd1;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class Model {
    
    private final List<Integer> lottoResults;
    
    public Model() {
        lottoResults = new ArrayList<>();
    }
    
    public List<Integer> getLottoResults( ) {
        int i = 0; 
        boolean results = false;
        lottoResults.clear();
        while (results != true) {
            int randInt = 0;
            while (randInt == 0 ) {
                randInt = new Random().nextInt(61);
            }
            if (lottoResults.contains(randInt)) {
                lottoResults.clear();
            }
            lottoResults.add(randInt); 
            if (lottoResults.size() >= 6) {
                results = true;
            }
        }
        return lottoResults;
    }
}