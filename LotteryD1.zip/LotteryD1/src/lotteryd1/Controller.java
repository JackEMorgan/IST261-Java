package lotteryd1;

import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;

public class Controller {
    
    private final Model model;
    private final View view;
    
    public Controller() {
        model = new Model();
        view = new View(this);
    }

    public String doLotteryDrawing(String nums) {
        nums = nums.trim();
        String[] arrayNums = nums.split("\\s+");
        String numRange = "([1-9]|[1-5][0-9]|60)";
        String regex = "(?:"+numRange+"\\s+){5}"+numRange;
       
        if (!nums.matches(regex)) {
            view.showErrorMsg("One or more expected inputs is invalid");
            return "";
        }  
            
        List<Integer> lottoResults = model.getLottoResults();
            
        String[] matchingNums = compareArrays(lottoResults, arrayNums);
            
        return "You Entered  " + Arrays.toString(arrayNums) + 
               "\n" + "The numbers from the lottery drawing are " + lottoResults +
                "\n" + "The matching numbers are " + Arrays.toString(matchingNums);
        }
    
    public String[] compareArrays(List<Integer> lottoNums, String[] userNums) {
        int i = 0;
        ArrayList<String> matchingNums = new ArrayList<>();
        for (i = 0; i < userNums.length; i++) {
            if (lottoNums.contains(Integer.valueOf(userNums[i]))) {
                matchingNums.add(userNums[i]);
            }
        }
        return matchingNums.toArray(new String[matchingNums.size()]);
    }
    
    public View getView() {
        return view;
    }
}