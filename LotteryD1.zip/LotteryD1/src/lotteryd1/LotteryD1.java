package lotteryd1;


public class LotteryD1 {

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> {
            Controller cntl = new Controller();
            cntl.getView().displaySelf();
        });
    }
    
}
