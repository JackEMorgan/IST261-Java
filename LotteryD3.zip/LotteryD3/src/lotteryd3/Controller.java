package lotteryd3;

import java.util.Set;
import java.util.HashSet;

public class Controller {
    
    private final Model model;
    private final View view;
    
    public Controller() {
        model = new Model();
        view = new View(this);
    }  
    
    public String doLotteryDrawing(String nums, String numDrawings) {
        String[] arrayNums = nums.split("\\s+");
        String numRange = "([1-9]|[1-5][0-9]|60)";
        String regex = "(?:"+numRange+"\\s+){5}"+numRange;
        
        String numDrawingsRange = "([1-9]|[1-9][0-9]{1,4}|100000)";
        
        if (!nums.matches(regex) && !nums.matches(numDrawingsRange)) {
            view.showErrorMsg("Unexpected Input in Both the Number"
                    + " of Drawings and the User Numbers Inputed.");
            return ""; } 
        else if (!nums.matches(regex)) {
           view.showErrorMsg("One or more expected inputs is invalid");
           return ""; }  
        else if (!numDrawings.matches(numDrawingsRange)) {
           view.showErrorMsg("Unexpected Input in Number of Drawings Field.");
           return ""; } 

        String results = "";
        int zeroMatches = 0;
        int oneMatch = 0;
        int twoMatches = 0;
        int threeMatches = 0;
        int fourMatches = 0;
        int fiveMatches = 0;
        int sixMatches = 0;
        
        int numOfDrawings = Integer.parseInt(numDrawings);
        Set<Integer> lottoResults = new HashSet<>();
        for (int i = 0; i < numOfDrawings; i++) {
           lottoResults = model.getLottoResults();
           int numMatches = findMatches(lottoResults, arrayNums); 
            switch (numMatches) {
                case 0 -> zeroMatches++;
                case 1 -> oneMatch++;
                case 2 -> twoMatches++;
                case 3 -> threeMatches++;
                case 4 -> fourMatches++;
                case 5 -> fiveMatches++;
                default -> sixMatches++;
            }
           results = "You entered: " + nums + "\n"
                   + zeroMatches + " drawings matched 0 of your numbers. \n"
                   + oneMatch + " drawings matched 1 of your numbers. \n" 
                   + twoMatches + " drawings matched 2 of your numbers. \n"
                   + threeMatches + " drawings matched 3 of your numbers. \n"
                   + fourMatches + " drawings matched 4 of your numbers. \n"
                   + fiveMatches + " drawings matched 5 of your numbers. \n"
                   + sixMatches + " drawings matched 6 of your numbers. \n";
        }    
        return results;
        }
    
    public int findMatches(Set<Integer> lottoNums, String[] userNums) {
        HashSet<String> matchingNums = new HashSet<>();
        for (String userNum : userNums) {
            if (lottoNums.contains(Integer.valueOf(userNum))) {
                matchingNums.add(userNum);
            }
        }
        int numMatches = matchingNums.size();
        return numMatches;
    }
    
    public View getView() {
        return view;
    }
}