package lotteryd3;

public class LotteryD3 {

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> {
            Controller cntl = new Controller();
            cntl.getView().displaySelf();
        });
    }
}
