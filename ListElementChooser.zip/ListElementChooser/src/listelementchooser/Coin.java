package listelementchooser;

public class Coin {
    final private String name;
    final private double value;
    
    
    public Coin(String name, double value) {
        this.name = name;
        this.value = value;
    }
    
    @Override
    public String toString() {
        return name + ": " + value;
    }
}