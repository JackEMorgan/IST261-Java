package listelementchooser;

import java.util.ArrayList;

public class ListElementChooser {

    
    public static void main(String[] args) {
        ArrayList<Coin> listOfCoins = createListOfCoins();
        
        Chooser<Coin> coinChooser = new Chooser<>(listOfCoins);
        
        for (int i = 0; i < 10; i++) {
            System.out.println(coinChooser.choose());
        }
    }
    
    private static ArrayList<Coin> createListOfCoins() {
        ArrayList<Coin> coins = new ArrayList<>();
        coins.add(new Coin("penny", 0.01));
        coins.add(new Coin("nickle", 0.05));
        coins.add(new Coin("dime", 0.1));
        coins.add(new Coin("quarter", 0.25));
        coins.add(new Coin("half dollar", 0.5));
        coins.add(new Coin("dollar", 1.0));
        return coins;
    }
    
}
