package jsonoutput;

import java.util.Arrays;

public class Student {
   
    private final String firstName;
    private final String lastName;
    private final double gpa;
    private final PhoneNumber phoneNumber;
    private final String[] skills;
    
    public Student(String firstName, String lastName, double gpa, String phoneNumString, String skillsString) {
        this.firstName =  firstName;
        this.lastName = lastName;
        this.gpa = gpa;
        this.phoneNumber = new PhoneNumber(phoneNumString);
        this.skills = skillsString.split(";");
    }
    
    @Override
    public String toString() {
        return "firstname: " + firstName + ", lastname: " + lastName + ", gpa: " + gpa + ", " + phoneNumber + ", skills: " + Arrays.toString(skills);
    }
}