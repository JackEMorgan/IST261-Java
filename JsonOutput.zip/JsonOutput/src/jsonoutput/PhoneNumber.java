package jsonoutput;

public class PhoneNumber {
    
    private final int areaCode;
    private final int prefix;
    private final int lineNum;
    
    public PhoneNumber(String phoneNumString) {
        String[] numPieces = phoneNumString.split("-");
        this.areaCode = Integer.parseInt(numPieces[0]);
        this.prefix = Integer.parseInt(numPieces[1]);
        this.lineNum = Integer.parseInt(numPieces[2]);
    } 
    
    @Override
    public String toString() {
        return "phonenumber=(" + areaCode + ") " + prefix + "-" + lineNum;
    }
}