package findmax;

import java.util.Arrays;
import java.util.List;

public class FindMax {

    public static void main(String[] args) {

        List<Integer> firstList = Arrays.asList(9, -7, 15, 0, -2, 22, 25, 8, 4, 26);
        List<Integer> secondList = Arrays.asList(1, 5, -15, 35, -8, 4, 9, 47, 22, -6, 47);
        List<Integer> thirdList = Arrays.asList(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

        System.out.println("The maximum of " + firstList + " is "
                + calculateMaximum(firstList));
        System.out.println("The maximum of " + secondList + " is "
                + calculateMaximum(secondList));
        System.out.println("The maximum of " + thirdList + " is "
                + calculateMaximum(thirdList));
    }

    private static int calculateMaximum(List<Integer> numbers) {
        int max = numbers.get(0);
        for (int in : numbers) {
            if (in > max) {
                max = in;
            } 
        }
        return max;
    }

}
